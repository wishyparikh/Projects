/*counter.h*/

//
// <<Wishy Parikh>>
// U. of Illinois, Chicago
// CS 341, Fall 2018
// Project #03: Counter container
//
// The Counter container is a set with no duplicates.  However, it keeps
// a count of how many times an element was inserted, hence the name
// "Counter".  Users of the Counter container can test for set membership,
// as well as obtain an element's count.
// 
// Example:  suppose C is a Counter, and you insert the elements 3, 11, 
// 5, 11, 3, and 11.  Then C contains the elements {3, 5, 11}, where 3's 
// count is 2, 5's count is 1, and 11's count is 3.
//
// Given N elements, search operations are O(lgN), and insert is O(N); these
// are average-time complexities.  In terms of space, the container will 
// consume at most 4N space.
// 

#pragma once

#include <iostream>
#include <iterator>

using std::cout;  
using std::endl;


template<typename T>

class Counter                      //this is a counter class i made my own container.
{
private:
	struct bst_node {                                // structure to make the whole new tree and store data in it.
		T      val;
		bst_node *left;
		bst_node *right;
		int countOf = 0;
		int leftNodeCount = 0;
		int rightNodeCount = 0;

		bst_node(const T & _val = T{}, bst_node * l = nullptr, bst_node *r = nullptr, int c=0)
			: val{ _val }, left{ l }, right{ r }, countOf{ c }
		{ }
	};
	bst_node *root;
    
  class iterator                   // class inside a class. like inception "dream within a dream"  an iterator class to iterate through the tree.
  { 
  public:
  struct list               // to iterate i converted tree into linked list
    {
      T      data;
      list   *next;
      int    count;

      list( const T & d = T{}, list * n = nullptr, int x = 0)
        : data{ d },  next{ n }, count{ x } { }

    };
    list *front;
    list *back;
  
  
  iterator()
  {
  front = nullptr; 
  back = nullptr;
  }
  
  
   void push_back(const T & val, const int count) {         // function to puch elements in linked list
      list *tmp = new list(val, nullptr, count);

      if(front == nullptr) {
        front = back = tmp;
		
      }
      else {
        back->next = tmp;
        back = tmp;
		
      }
    }
    
    void printInorder(bst_node* node)  //inorder traversal of the tree and store data in it.
{ 
    if (node == NULL) 
        return; 
  
    
    printInorder(node->left); 
  
    
   push_back(node->val,node->countOf); 
  
   
    printInorder(node->right); 
} 




  void iteratormake(bst_node *temp)         // function to make a linked list and store data in it.
  {
   printInorder(temp);
  }
  
  iterator& operator++ ()         // tyoes of operators that can be used with the iterator object.
  {
  front = front->next;
  return *this;
  }
    
    
    const T& operator* ()
    {
        return front->data;
    }
    
    
    bool operator != (const iterator& rhs)
    {
    if((!(this->front<rhs.front)) && (!(rhs.front<this->front)))
    {
    return false;
    }
   
   else 
   {
    return true;
    }
    }
};

public:
  //
  // constructor:
  //
  Counter()                      //main container class constructor to initialize the main root of the tree.
  {
    
	root = nullptr;
  }
  
  
  //
  // copy constructor:
  //
  Counter(const Counter& other)            // copy constructor to copy a tree.
  {
    

	  root=recurcopy(other.root);
	
  }
  
   bst_node* recurcopy(const bst_node *temp)            // this is a helper recursive function to copy a tree.
  {
	  if (temp == NULL)
	  {
		  return NULL;
	  }
	  bst_node *tempNode = new bst_node;
	  tempNode->val = temp->val;
	 
     
     tempNode->left = recurcopy(temp->left);
	 
     tempNode->right = recurcopy(temp->right);
	 
     
     tempNode->countOf = temp->countOf;
	  return tempNode;
  }
  
  //
  // destructor:
  // 
  ~Counter()             // destructor to destro memory
  { 
     delete_nodes(root);
	root = nullptr;
  }



private:
	
	static int get_size(bst_node *temp) {
		if (temp == nullptr)
		{
			return 0;
		}
		else
		{
			return get_size(temp->left) + get_size(temp->right) + 1;
		}
	}

public:
	int size() const  // a function to get size of the tree. and above it is a recursive function to find the height of the tree.
	{
		return get_size(root);
	}
  
  
  //
  // empty()
  //
  // Returns true if the set is empty, false if not.
  // 
  // Time complexity: O(1).
  // 
  bool empty() const      // function to check if the tree is empty.
  {
    if(root == nullptr)
    return true;
    
    else
    return false;
  }
  
  
  //
  // clear()
  //
  // Empties the set, deleting all elements and counts.
  
  private: 
  void delete_nodes(bst_node *temp) {         // function to delete the nodes of the tree and initialize it to nulll.
	  if (temp == nullptr) 
      return;
      
	  delete_nodes(temp->left);
	  delete_nodes(temp->right);
	  delete temp;
  }
 public: 
  void clear()
  {
    
	  delete_nodes(root);
	  root = nullptr;
  }
  
  
  //
  // [e]
  //
  // Returns true if set contains e, false if not.
  //
  // NOTE: since the type of e is unknown, elements are compared using <. 
  // This implies 2 elements x and y are equal if (!(x<y)) && (!(y<x)).
  // 
  // Time complexity: average-case O(lgN).
  //
  bool operator[](const T& e)      // types of operators that can be used with the counter objects.
  {
    
	bst_node *p = root;

	while (p != nullptr) 
	{
		if (!(p->val<e) && !(e<p->val))
		{
			
			return true;
			
		}
		if (e < p->val)
		{
			p = p->left;
		}
		else
		{
			p = p->right;
		}
	}
	return false;
  }


  //
  // (e)
  // 
  // Returns a count of how many times e has been inserted into the set;
  // the count will be 0 if e has never been inserted.
  // 
  // NOTE: since the type of e is unknown, elements are compared using <. 
  // This implies 2 elements x and y are equal if (!(x<y)) && (!(y<x)).
  // 
  // Time complexity: average-case O(lgN).
  // 
  int operator()(const T& e) const          // types of operators that can be used with the counter objects.
  {
    
	  bst_node *p = root;

	  while (p != nullptr)
	  {
		  
		 
		 if(!(p->val<e) && !(e<p->val))
         {
             return p->countOf;
         }
		  if (e < p->val)
		  {
			  p = p->left;
		  }
		  else
		  {
			  p = p->right;
		  }
	  }
	 
	 return 0;
  }
 
 
  
  //
  // insert(e)
  // 
  // If e is not a member of the set, e is inserted and e's count set to 0.
  // If e is already in the set, it is *not* inserted again; instead, e's
  // count is increased by 1.  Sets are unbounded in size, and elements are
  // inserted in order as defined by T's < operator; this enables in-order 
  // iteration.
  // 
  // NOTE: since the type of e is unknown, elements are compared using <. 
  // This implies 2 elements x and y are equal if (!(x<y)) && (!(y<x)).
  // 
  // Time complexity: worst-case O(N).
  // Space complexity: 4N.
  //
  //void 
   bst_node* helpinsert(bst_node *r,const T& e,bool &success)
   
  {
    
	   if (r == nullptr) 
       {
		   success = true;
		   bst_node* t= new bst_node(e, nullptr, nullptr, 0);
		   t->countOf++;
		   return t;
	   }

	   if ((!(r->val< e)) && (!(e<r->val)))
	   {
		   r->countOf++;
           success = false;
		   return r;
	   }
	   if (e < r->val)
	   {
		   
		   r->left = helpinsert(r->left, e, success);
		   if (success)
		   {
			   r->leftNodeCount++;
		   }

		   return r;
	   }
	   else
	   {
		   r->right = helpinsert(r->right, e, success);
		   if (success)
		   {
			   r->rightNodeCount++;
		   }
		   return r;
	   }
  }

   void insert(const T& e)                 // function to insert the elements in the tree and above it is a helper recursive
   {                                        //function to help inserting nodes in the tree as the values arrive.
	   bool success;
	   root = helpinsert(root, e, success);
   }
  
  
  // 
  // += e
  //
  // Inserts e into the set; see insert.
  //
  // Time complexity: worst-case O(N).
  // Space complexity: 4N.
  // 
  Counter& operator+=(const T& e)            // this operator can be used to insert values in the tree.
  {
    //
    // insert e into "this" set:
    //
    this->insert(e);

    // return "this" updated set:
    return *this;
  }
  
  
  //
  // lhs = rhs;
  //
  // Makes a deep copy of rhs (right-hand-side) and assigns into
  // lhs (left-hand-side).  Any existing elements in the lhs
  // are destroyed *before* the deep copy is made.
  // 
  // NOTE: the lhs is "this" object.
  //
 
 
 
 
Counter& operator=(Counter& rhs)               //this operator assignes rhs to lhs. and makes a copy of rhs into lhs.
  { 
    //
    // NOTE: where is the lhs in the function call?  The lhs operand is 
    // hidden --- it's "this" object.  So think this->operator=(rhs).  
    //

    // check for self-assignment:
    if (this == &rhs)  // S = S;
      return *this;
   
   this->clear();
    
  this->root = recurcopy(rhs.root);
    

   
    return *this;
  }
  

  //
  // begin()
  // 
  // Returns an iterator denoting the first element of the set.  If the 
  // set is empty, begin() == end().  The iterator will advance through
  // the elements in order, as defined by T's < operator.
  //
  iterator begin()                      // begin function to make iterator begin in the first value of the linked list.
  {
    iterator first;
    first.iteratormake(root);
    return first;
  }
  
  
  //
  // end()
  // 
  // Returns an iterator denoting the end of the iteration space --- i.e.
  // one past the last element of the set.  If the set is empty, then
  // begin() == end().
  // 
  iterator end()                 //end will point to the 1 past the last value that is basically null.
  {
    iterator last;
    last.front = nullptr;
    last.back = nullptr;
    return last; 
  }
  //system("pause");
  //
  //
 
};
