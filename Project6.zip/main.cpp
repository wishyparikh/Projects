/*main.cpp*/

//
// <<Wishy Parikh>>
// U. of Illinois, Chicago
// CS 341, Fall 2018
// Project #03: Counter container
// 
// Test cases for Counter container, which acts like a set but keeps a count
// of how many times each element was inserted.  
//
// References:
//   Unit testing based on Catch framework: https://github.com/catchorg/Catch2
//   Catch tutorial: https://github.com/catchorg/Catch2/blob/master/docs/tutorial.md#top
//   install:     sudo apt-get install catch
//   compilation: g++ -std=c++11 -Wall -o main.exe main.cpp
//   execution:   ./main.exe
//

// let Catch provide main():
#define CATCH_CONFIG_MAIN

// gain access to Catch framework:
#include <catch.hpp>

// our Counter class:
#include "counter.h"

// *****************************************************************
//
// Test cases:
// 
// *****************************************************************

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

 

TEST_CASE( "empty Counter<int>", "[Counter]" )    //this is professor's test case.
{
  Counter<int> C;

  REQUIRE(C.empty() == true);
  REQUIRE(C.size() == 0);
}//test


TEST_CASE("check empty and see if both iterators are null", "[COUNTER]")  //this is my test case
{
    Counter<int> C;
	
	SECTION("check that begin == end for empty counter")
	{
		REQUIRE(!(C.begin() != C.end()));
	}
}

TEST_CASE( "Counter<int> with  2 containers and testing lhs = rhs function and Iterator .", "[Counter]" )  // this is my test case
{
  Counter<int> C1;
    Counter<int> C2;
    int j = 3000;

  REQUIRE(C1.size() == 0);
  REQUIRE(C1.empty() == true);
  
  SECTION("inserting elements")
  {
      for(int i = 0;i<500 ;i++)
        C1.insert(i);
    
   
    for (int i =0;i<100; i++)
    {
        C2.insert(j);
        j++;
    }
  
     C1 = C2;
   
      C1.insert(66);
      
     auto x = C1.begin();
     
      
   
      REQUIRE(*x == 66);
      REQUIRE(*++x == 3000);
      REQUIRE(C1[3002]);
        REQUIRE(C1[66]);
     }
}//test


TEST_CASE("Copy constructor test", "[Counter]"){      // this is my test case.
	SECTION("With ints"){
		Counter<int> counter; 
		Counter<int> randomNums;
		int count = 100;
		for (int i = 0; i < count; i++){
			randomNums.insert((rand() % 1000000) + 1);
		}
		 // texting "=" operator 
		counter = randomNums;
		Counter<int> copyCounter(counter); 
		REQUIRE(counter.size() == copyCounter.size()); 
		//clear the original one 
		counter.clear(); 
		REQUIRE(copyCounter.size() > counter.size()); 
		
		//make sure that a deep copy was made
		for (const auto& val : randomNums){
			REQUIRE(copyCounter[val] == true); 
		}
	}
}

TEST_CASE( "Counter<string> with 4 elements", "[Counter]" )  //this is professor test case.
{
  Counter<string> C;

  REQUIRE(C.size() == 0);
  REQUIRE(C.empty() == true);
  
  SECTION("inserting 1st element")
  {
    C.insert("apple");
    
    REQUIRE(C.size() == 1);
    REQUIRE(!C.empty());
    
    REQUIRE(C["apple"] == true);
    REQUIRE(C("apple") == 1);
    
    SECTION("inserting 3 more elements")
    {
      C += "banana";
      C.insert("pear");
      C += "pizza";
      
      REQUIRE(C.size() == 4);
      REQUIRE(!C.empty());
      
      REQUIRE(C["apple"] == true);
      REQUIRE(C["banana"] == true);
      REQUIRE(C["pear"] == true);
      REQUIRE(C["pizza"] == true);
      
      SECTION("checking element counts")
      {
        REQUIRE(C("apple") == 1);
        REQUIRE(C("banana") == 1);
        REQUIRE(C("pear") == 1);
        REQUIRE(C("pizza") == 1);
      }
      
      SECTION("checking non-elements")
      {
        REQUIRE(!C["appl"]);
        REQUIRE(!C["applee"]);
        REQUIRE(!C["Pear"]);
        REQUIRE(!C["piazza"]);
        REQUIRE(!C["zizza"]);
      }

      SECTION("checking non-element counts")
      {
        REQUIRE(C("appl") == 0);
        REQUIRE(C("applee") == 0);
        REQUIRE(C("Pear") == 0);
        REQUIRE(C("piazza") == 0);
        REQUIRE(C("zizza") == 0);
      }
    }
  }
}//test
