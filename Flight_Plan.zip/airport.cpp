#include "airport.h"


 MyLNode::MyLNode (int v1)
{
elem = v1;
identity ='0';
  next = NULL;
}
 MyLNode::MyLNode (int v1, MyLNode* n)
{
elem = v1;
identity='0';
  next = n;
}

void MyLNode::setIdentity(char status)    // Set the identity of Visited or Unvisited
{
	identity = status;
}

char MyLNode::getIdentity() 
{
	return identity;
}

void MyLNode::setstatv(char s)
{
identity=s;
}
  
  void MyLNode::setElem (int e)
{
elem = e;
}
  int MyLNode::getElem ()
{
return elem;
}
  void MyLNode::setNext (MyLNode* n)
{
next = n;
}
  MyLNode* MyLNode::getNext()
{
return next;
}




void Track::setsize(int val1)
{
size=val1;
}

int Track::getsize()
{
return size;
}





MyList::MyList()
{
  head = NULL;
  
}
   
  
  void MyList::insert(int v1)
  {
 MyLNode* tmp = new MyLNode (v1);
  
  // this code just inserts the node at the beginning of the list
  tmp->setNext (head);
  head = tmp;
 
}

void MyList::show()
{
MyLNode* temp;
temp=head;
if(temp==NULL)
{
printf("No direct connection\n");
return;
}

while(temp!=NULL)
{
printf(" %d ",temp->getElem());

temp=temp->getNext();
}
printf("\n");
}


void MyList::remove(int val)
{
 
    MyLNode *temp = head, *prev;
 
    if (temp != NULL && temp->getElem() == val)
    {
        head = temp->getNext();   
        free(temp);              
        return;
    }
 
    while (temp != NULL && temp->getElem() != val)
    {
        prev = temp;
        temp = temp->getNext();
    }
 
    if (temp == NULL) 
    return;
 
    prev->setNext(temp->getNext());
 
    free(temp);

}

void MyList::makeIdentityU()        // Setting the identity U for all nodes in linked list.
{
//printf("YYOYOYOYOYOYOYOYO\n");
	MyLNode* ptr;
	ptr = head;    
//printf("ggwp\n");        // Fix me.

if(head==NULL)
{
//printf("ggwp\n");
}

	while (ptr != NULL)
	{

		ptr-> setIdentity('U');
		ptr = ptr->getNext();
	}


}

void MyList::makeIdentityV()
{

	MyLNode* ptr;
	ptr = head;

	if (ptr == NULL)
	{
		return ;
	}
	
	while (ptr != NULL && ptr->getIdentity() != 'U')
	{
		//printf(" VVVVV \n");
		//ptr->setIdentity('V');
		ptr = ptr->getNext();
	}

	//printf(" value is %d\n", ptr->getElem());
	//printf(" VVVVV \n");
	ptr->setIdentity('V');
	//printf(" making identity V is %c\n", ptr->getIdentity());
	
}

char MyList::checkIdentity()
{
	// printf(" got it \n");
	MyLNode* ptr;
	ptr = head;

	if (ptr == NULL)
	{
		//printf(" got it \n");
		return -1;
	}
	if (ptr != NULL && getNumberOfCurrentValues()==1)
	{
		//printf(" value is %d\n", ptr->getElem());
		//printf(" identitttty is %c\n", ptr->getIdentity());
		return ptr->getIdentity();
	}
	else
	{
		while (ptr != NULL && ptr->getIdentity() != 'U')
		{

			//printf(" identity is %c\n", ptr->getIdentity());
			ptr = ptr->getNext();
		}

		if (ptr == NULL)
		{
			return 'a';
		}   
		//printf(" value is %d\n", ptr->getElem());
		return ptr->getIdentity();
	}
}

int MyList::getNumberOfCurrentValues()
{
	MyLNode* ptr;
	ptr = head;
	int count = 0;
	while (ptr != NULL)
	{
		count++;
		ptr = ptr->getNext();
	}

	return count;
}

int MyList::getNthValue( int v1)
{
	MyLNode* ptr;
	ptr = head;
	int count = 0;

	if (ptr == NULL)
	{
		//printf(" Node is NULL");
		return -1;
	}
	while (ptr != NULL)
	{
		count++;
		if (count == v1) 
		{
			return ptr->getElem();
		}
		ptr = ptr->getNext();
	}
}