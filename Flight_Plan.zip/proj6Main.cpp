#include "airport.h"

class TravelNetwork
{
 private:
MyList *list;
Track t;
   // Create the Data Members for the Travel Network here
  
 public:
  
 // Use a constructor to initialize the Data Members for Travel Network
 TravelNetwork()
 {
//list=(MyList*)malloc(10*sizeof(MyList));
  list=NULL;
 }
  
  
 // The main loop for reading in input
 void processCommandLoop (FILE* inFile)
 {
  char  buffer[300];
  char* input;
  printf("Enter command or '?' to get the list of commands \n");

  input = fgets ( buffer, 300, inFile );   // get a line of input
    
  // loop until all lines are read from the input
  while (input != NULL)
  {
    // process each line of input using the strtok functions 
    char* command;
    command = strtok (input , " \n\t");

    //printf ("*%s*\n", command);
    
    if ( command == NULL )
      printf ("Blank Line\n");
 
    else if ( strcmp (command, "q") == 0) 
	{
	printf("Terminating \n");
      	exit(1);
	}
     
    else if ( strcmp (command, "?") == 0) 
      showCommands();
     
    else if ( strcmp (command, "t") == 0) 
      doTravel(&list);
     
    else if ( strcmp (command, "r") == 0) 
      doResize(&list);

    else if ( strcmp (command, "i") == 0) 
      doInsert(&list);

    else if ( strcmp (command, "d") == 0) 
      doDelete(&list);

    else if ( strcmp (command, "l") == 0) 
      doList(&list);

    else if ( strcmp (command, "f") == 0) 
      doFile();

    else if ( strcmp (command, "#") == 0) 
      ;
     
    else
      printf ("Command is not known: %s\n", command);
     
    input = fgets ( buffer, 300, inFile );   // get the next line of input

  }
return;
 }
 
 void showCommands()
 {
   printf ("The commands for this project are:\n");
   printf ("  q \n");
   printf ("  ? \n");
   printf ("  # \n");
   printf ("  t <int1> <int2> \n");
   printf ("  r <int> \n");
   printf ("  i <int1> <int2> \n");
   printf ("  d <int1> <int2> \n");
   printf ("  l \n");
   printf ("  f <filename> \n");
 }
 
void doTravel(MyList** airports)
	{
		int val1 = 0;
		int val2 = 0;

		// get an integer value from the input
		char* next = strtok(NULL, " \n\t");
		if (next == NULL)
		{
			printf("Integer value expected\n");
			return;
		}
		val1 = atoi(next);
		if (val1 == 0 && strcmp(next, "0") != 0)
		{
			printf("Integer value expected\n");
			return;
		}

		// get another integer value from the input
		next = strtok(NULL, " \n\t");
		if (next == NULL)
		{
			printf("Integer value expected\n");
			return;
		}
		val2 = atoi(next);
		if (val2 == 0 && strcmp(next, "0") != 0)
		{
			printf("Integer value expected\n");
			return;
		}
		if ((val1> t.getsize()) || (val2>t.getsize()))
		{
			printf(" No airport exist.\n");
			return;
		}


		printf("Performing the Travel Command from %d to %d\n",
			val1, val2);

		int c = 0;
		MyList *ptrAirports = *airports;      // Ptr as temp pointing towards the airports.
		/*c = ptrAirports[2].getNumberOfCurrentValues();
		printf(" c is %d ", c);

		for (int i = 1; i <=c; i++)
		{
			int flag = 0;
			flag= ptrAirports[2].getNthValue(i);
			printf("\n Value of %d: %d \n", i, flag);
		}  */

		dfshelper(val1, val2, &ptrAirports);


	}

	void dfshelper(int x, int y, MyList **newlist)
	{
		MyList *List;
		List = *newlist;

		for (int i = 1; i <= t.getsize(); i++)
		{

			list[i].makeIdentityU();
//printf("YYOYOYOYOYOYOYOYO\n");
			//list[i].setLul();
		}
		

		// printf ("You can get from airport � %d � to airport � %d � in one or more flights\n",x,y);

		if (dfs(x, y, List) == true)
		{
			printf("You can get from airport � %d � to airport � %d � in one or more flights\n", x, y);
			printf("\n");

		}

		else
			printf("You can NOT get from airport � %d � to airport � %d � in one or more flights\n", x, y);
			printf("\n");
	
	}

	bool dfs(int a, int b, MyList *planelist)
	{
		int c;
		MyList *originalList;
		originalList = planelist;

		//c = gg[a].getNthValue(1);
		//printf(" Value of c is %d: ", c);

	LOOP:for (int i = 1; i <= originalList[a].getNumberOfCurrentValues(); i++)
		{
			//printf(" hello");
			c = originalList[a].getNthValue(i);
			//printf(" Value of c is %d: \n", c);   // Debug

			while (c != -1)
			{
				if (c == b)
					return true;

				else
				{
					//printf("jjjj");
					if (originalList[a].checkIdentity() == 'U')
					{
						originalList[a].makeIdentityV();
						if (dfs(c, b, originalList) == true)
						{
							return true;
						}
						else



						{
							break;
						}

					}
					else
					{
						//printf(" noooooooooo \n");
						break;
					}

				}
			}
		}
		
		//printf(" no flight from here");
		return false;


	}


 
 void doResize(MyList **list)
 {
   int val1 = 0;
//MyList list[val1];
// get an integer value from the input
   char* next = strtok (NULL, " \n\t");
   if ( next == NULL )
   {
     printf ("Integer value expected\n");
     return;
   }
   val1 = atoi ( next );
   if ( val1 == 0 && strcmp (next, "0") != 0)
   {
     printf ("Integer value expected\n");
     return;
   }
if(*list!=NULL)
free(*list);

if(val1<21)
{
*list=new MyList[val1+1];
t.setsize(val1);
}
else
{
printf("Invalid resize value \n");
return;
}

   
}
 
 void doInsert(MyList **list)
 {
int val1 = 0;
   int val2 = 0;
int size;
MyList *templist=*list;
if(templist==NULL)
{
printf("No airports use command 'r' first\n");
return;
}

   // get an integer value from the input
   char* next = strtok (NULL, " \n\t");
   if ( next == NULL )
   {
     printf ("Integer value expected\n");
     return;
   }
   val1 = atoi ( next );
   if ( val1 == 0 && strcmp (next, "0") != 0)
   {
     printf ("Integer value expected\n");
     return;
   }
   
   // get another integer value from the input
   next = strtok (NULL, " \n\t");
   if ( next == NULL )
   {
     printf ("Integer value expected\n");
     return;
   }
   val2 = atoi ( next );
   if ( val2 == 0 && strcmp (next, "0") != 0)
   {
     printf ("Integer value expected\n");
     return;
   }
   printf ("Performing the insert Command from %d to %d\n",val1, val2);

size=t.getsize();

printf("total number of airports are: %d\n",size);

if(val1>size)
{
printf("cannot allot in this airport\n");
return;
}
if(val2>size)
{
printf("cannot allot in this airport\n");
return;
}
else
{

templist[val1].insert(val2);

}
}
 
 void doDelete(MyList **list)
 {
MyList *templist=*list;
int val1 = 0;
   int val2 = 0;
if(templist==NULL)
{
printf("No airports use command 'r' first\n");
return;
}

   // get an integer value from the input
   char* next = strtok (NULL, " \n\t");
   if ( next == NULL )
   {
     printf ("Integer value expected\n");
     return;
   }
   val1 = atoi ( next );
   if ( val1 == 0 && strcmp (next, "0") != 0)
   {
     printf ("Integer value expected\n");
     return;
   }
   
   // get another integer value from the input
   next = strtok (NULL, " \n\t");
   if ( next == NULL )
   {
     printf ("Integer value expected\n");
     return;
   }
   val2 = atoi ( next );
   if ( val2 == 0 && strcmp (next, "0") != 0)
   {
     printf ("Integer value expected\n");
     return;
   }
   
   
   printf ("Performing the delete Command from %d to %d\n",val1, val2);



templist[val1].remove(val2);

}
 
 void doList(MyList **list)
 {
int size;
int i;
size=t.getsize();
MyList *templist;
templist=*list;
for(i=1;i<=size;i++)
{
printf("Airport %d has direct connection to these airports\n",i);
templist[i].show();
}  
 





}
 
void doFile()
{

  TravelNetwork airportdata;
   // get a filename from the input
   char* fname = strtok (NULL, " \n\t");
   if ( fname == NULL )
   {
     printf ("Filename expected\n");
     return;
   }






FILE *src;
if ( ( src = fopen( fname , "r" )) == NULL)
{
    printf ( "Can't open input file: %s\n", fname );
    return;
}

airportdata.processCommandLoop(src);


fclose(src);




return;


   
   // next steps:  (if any step fails: print an error message and return ) 
   //  1. verify the file name is not currently in use
   //  2. open the file using fopen creating a new instance of FILE*
   //  3. recursively call processCommandLoop() with this new instance of FILE* as the parameter
   //  4. close the file when processCommandLoop() returns
 }
};

int main (int argc, char** argv)
{
  // set up the variable inFile to read from standard input
  FILE* inFile = stdin;

  // set up the data needed for the airport adjcency list
  TravelNetwork airportData;
   
  // call the method that reads and parses the input
  airportData.processCommandLoop (inFile);
   
  printf ("Goodbye\n");
  return 1;
 }