#include <cstdio>
#include <cstring>
#include <cstdlib>




class MyLNode
{
 private:
  int elem;
  char identity;
  MyLNode* next;
  
 public:
  MyLNode (int v1);

  MyLNode (int v1, MyLNode* n);


void setIdentity(char status);    


char getIdentity();

void setstatv(char s);
  
  void setElem (int e);
  int getElem ();
  void setNext (MyLNode* n);
  MyLNode* getNext();
};

class Track
{
private:
int size;


public:

void setsize(int val1);

int getsize();

};


class MyList
{
 private:
  MyLNode* head;

  
 public:
  MyList();
   
  
  void insert(int v1);

void show();


void remove(int val);

void makeIdentityU();        // Setting the identity U for all nodes in linked list.

void makeIdentityV();
char checkIdentity();

int getNumberOfCurrentValues();
int getNthValue( int v1);
};