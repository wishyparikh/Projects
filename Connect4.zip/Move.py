import sys
# This is the move class to give the type of move specified by the user.


class Move:
    @staticmethod
    def makeMove(board, player, column, BOARDHEIGHT):  # Make move function due to type of player.
        for y in range(BOARDHEIGHT-1, -1, -1):
            if board[column][y] == ' ':
                board[column][y] = player
                return

    @staticmethod
    def isValidMove(board, move, BOARDWIDTH):   # Check is the move was a valid move.
        if move < 0 or move >= BOARDWIDTH:
            print("Invalid move, outside board, try again: ")
            return False

        if board[move][0] != ' ':
            print("Invalid move, Column is full, try again: ")
            return False
        return True

    @staticmethod
    def getHumanMove(board, BOARDWIDTH):   # Get the input from the user check if its the digit.
        while True:
            move = input()
            if move.lower().startswith('q'):
                sys.exit()
            if not move.isdigit():
                continue
            move = int(move) - 1
            if Move.isValidMove(board, move, BOARDWIDTH):
                return move
