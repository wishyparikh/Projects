import connect
# This the Driver class that makes an object and calls the Play function to play game


class Driver:
    g1 = connect.Game(7, 6)
    g1.Play()
