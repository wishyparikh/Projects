import Move
# This is the game class that Plays the whole game.


class Game:
    BOARDWIDTH = 0
    BOARDHEIGHT = 0

    def __init__(self, x, y):  # Constructor to take the size. we can also increase the size of the board
        self.BOARDWIDTH = x
        self.BOARDHEIGHT = y

    def Play(self):  # Play function to play the game and take the moves.

        space = eval(input("Please choose the board spacing: "))
        if space > 2:
            space = 0
        if space < 0:
            space = 0
        while True:
            nummove = 0
            Player1Tile = 'R'    # 2 variables for Players We can also increase the number of players.
            Player2Tile = 'B'
            turn = 'Player 1'
            print('Type the column in which you wish to move.')
            mainBoard = self.getNewBoard()

            while True:    # while loop for playing the game. and taking input
                nummove = nummove + 1
                if turn == 'Player 1':
                    self.drawBoard(mainBoard, space)
                    print("Turn ", nummove, ": Player 1 (R), choose your move:")
                    move = Move.Move.getHumanMove(mainBoard, self.BOARDWIDTH)
                    Move.Move.makeMove(mainBoard, Player1Tile, move, self.BOARDHEIGHT)
                    if self.isWinner(mainBoard, Player1Tile):
                        winner = 'Player 1'
                        break
                    turn = 'Player 2'
                else:
                    self.drawBoard(mainBoard, space)
                    print("Turn ", nummove, ": Player 2 (B), choose your move:")
                    move = Move.Move.getHumanMove(mainBoard, self.BOARDWIDTH)
                    Move.Move.makeMove(mainBoard, Player2Tile, move, self.BOARDHEIGHT)
                    if self.isWinner(mainBoard, Player2Tile):
                        winner = 'Player 2'
                        break
                    turn = 'Player 1'

                if self.isBoardFull(mainBoard):
                    winner = 'tie'
                    break

            self.drawBoard(mainBoard, space)
            print('Winner is: %s' % winner)
            if not self.playAgain():
                print("Goodbye!")
                break

    def playAgain(self):            # Play again game if yes then return yes.
        # This function returns True if the player wants to play again, otherwise it returns False.
        print('Play again? (y/n)')
        return input().lower().startswith('y')

    def drawBoard(self, board, spacing):  # Drawing board according to the spacing given by the user
        if spacing == 0:    # for spacing 0
            print(' ', end='')

            print()
            print('+-+' + ('-+' * (self.BOARDWIDTH - 1)))

            for y in range(self.BOARDHEIGHT):

                print('|', end='')
                for x in range(self.BOARDWIDTH):
                    print('%s|' % board[x][y], end='')
                print()

                print('+-+' + ('-+' * (self.BOARDWIDTH - 1)))
            for x in range(1, self.BOARDWIDTH + 1):
                print(' %s' % x, end='')
            print()
        if spacing == 1:           # for spacing 1
            print(' ', end='')
            print()
            print('+---+' + ('---+' * (self.BOARDWIDTH - 1)))

            for y in range(self.BOARDHEIGHT):

                print('|', end='')
                for x in range(self.BOARDWIDTH):
                    print(' %s |' % board[x][y], end='')
                print()

                print('+---+' + ('---+' * (self.BOARDWIDTH - 1)))
            for x in range(1, self.BOARDWIDTH + 1):
                print('  %s ' % x, end='')
            print()
        if spacing == 2:       # for spacing 2
            print(' ', end='')
            print()
            print('+-----+' + ('-----+' * (self.BOARDWIDTH - 1)))

            for y in range(self.BOARDHEIGHT):

                print('|', end='')
                for x in range(self.BOARDWIDTH):
                    print('  %s  |' % board[x][y], end='')
                print()

                print('+-----+' + ('-----+' * (self.BOARDWIDTH - 1)))
            for x in range(1, self.BOARDWIDTH + 1):
                print('   %s  ' % x, end='')
            print()

    def getNewBoard(self):   # Get a new boar at the start of the game. clearing the previous input
        board = []
        for x in range(self.BOARDWIDTH):
            board.append([' '] * self.BOARDHEIGHT)
        return board

    def isBoardFull(self, board):    # check if the board is ful of inputs.
        for x in range(self.BOARDWIDTH):
            for y in range(self.BOARDHEIGHT):
                if board[x][y] == ' ':
                    return False
        return True

    def isWinner(self, board, tile):   # check if the input was winning move.
        # check horizontal spaces
        for y in range(self.BOARDHEIGHT):
            for x in range(self.BOARDWIDTH - 3):
                if board[x][y] == tile and board[x+1][y] == tile and board[x+2][y] == tile and board[x+3][y] == tile:
                    return True

        # check vertical spaces
        for x in range(self.BOARDWIDTH):
            for y in range(self.BOARDHEIGHT - 3):
                if board[x][y] == tile and board[x][y+1] == tile and board[x][y+2] == tile and board[x][y+3] == tile:
                    return True

        # check / diagonal spaces
        for x in range(self.BOARDWIDTH - 3):
            for y in range(3, self.BOARDHEIGHT):
                if board[x][y] == tile and board[x+1][y-1] == tile and board[x+2][y-2] == tile and board[x+3][y-3] == tile:
                    return True

        # check \ diagonal spaces
        for x in range(self.BOARDWIDTH - 3):
            for y in range(self.BOARDHEIGHT - 3):
                if board[x][y] == tile and board[x+1][y+1] == tile and board[x+2][y+2] == tile and board[x+3][y+3] == tile:
                    return True

        return False
