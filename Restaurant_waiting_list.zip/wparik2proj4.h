#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define TRUE 1
#define FALSE 0

//typedef enum {FALSE = 0, TRUE, NO = 0, YES} boolean;


struct nodeStruct			//structure for 3 variable linked list
{
 char status;	
 int seat;
 char *naam;
 struct nodeStruct*  next;
};
typedef struct nodeStruct node;

void clearToEoln();
int getPosInt();
char *getName();
int getNextNWSChar();
void printCommands();

void doAdd(node** line ,char ch,int debugMode);
void doCallAhead(node** line ,char ch);
void doWaiting(node** line ,char ch);
void doRetrieve(node** line,int debugMode);
void doList(node** line ,char ch);
void doDisplay(node** line);

int DoesNameExist(node* curr,char* name,char ch);
node* addToList(node* line,char*name,int size, char ch);
int UpdateStatus(node* temp,char* name);
char* retriveandRemove(node** line,int size);
int CountGroupsAhead(node *line,char* name);
int DisplayGroupSizeAhead(node* temp,node* t,char* name);
void DisplayListInfo(node* temp);

