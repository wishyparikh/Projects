#include "wparik2proj4.h"

int DoesNameExist(node* curr,char* name,char ch)
{
int x;
if(ch=='a'||ch=='c')
{
while(curr!=NULL)
{
if(strcmp(curr->naam,name)==0)
{
printf("name %s already exists\n",name);
x=1;
return x;
}
curr=curr->next;
}
}
if(ch=='w')
{
while(curr!=NULL)
{
if((curr->status=='A')&&(strcmp(curr->naam,name)==0))
{
x=1;
return x;
}
else if(curr->next==NULL)
{
//printf("name %s not found\n",name);
x=0;
return x;
}
curr=curr->next;
}
}
return 0;
}



node* addToList(node* line,char* name,int size, char ch)
{



if(ch=='a')
{
node* temp=line;

if(line==NULL)
{
node* ptr = (node*) malloc (sizeof(node));

//printf("adding 'a' at first\n");
 

 ptr->status = 'A';
 ptr->seat = size;
 ptr->naam=name;
 ptr->next=NULL;
  
 return ptr;
}

else
{

node* ptr = (node*) malloc (sizeof(node));
 ptr->status = 'A';
 ptr->seat = size;
 ptr->naam=name;
 ptr->next=NULL;
node* temp1=temp;
 while(temp->next!=NULL)
{
temp=temp->next;
}
 temp->next=ptr;
temp=temp1;
 line=temp;
}
return line;
}




if(ch=='c')
{
node* temp=line;
if(line==NULL)
{
node* ptr = (node*) malloc (sizeof(node));
// printf("adding 'c' at first\n");

 ptr->status = 'U';
 ptr->seat = size;
 ptr->naam=name;
 ptr->next=NULL;
  
return ptr;
}
else
{

node* ptr = (node*) malloc (sizeof(node));
 ptr->status = 'U';
 ptr->seat = size;
 ptr->naam=name;
 ptr->next=NULL;
node* temp1=temp;
 while(temp->next!=NULL)
{
temp=temp->next;
}
 temp->next=ptr;
temp=temp1;
 line=temp;

}
return line;
}
}

int UpdateStatus(node* temp,char* name)
{
int x=0;
if((temp->status=='U')&&(strcmp(temp->naam,name)==0))
{
temp->status='A';
x=1;
return x;
}
else if((temp->status=='A')&&(strcmp(temp->naam,name)==0))
{
x=0;
return x;
}
}



char* retriveandRemove(node** line,int size)
{
node* temp=*line;
node* t;

if(size>=temp->seat&&temp->status=='A')
{
node* ptr=temp;
ptr=ptr->next;

char* name;
name =temp->naam;
free(temp);
*line=ptr;
return name;
}

else 
  {
	t=temp;
     while((temp->next != NULL)&&(size<temp->seat||temp->status=='U'))
     {
        t=temp;
        temp=temp->next;
     }
	if(temp->next == NULL&&size>=temp->seat&&temp->status=='A')
	{
	
char* name;
name =temp->naam;
     free(t->next);
     t->next=NULL;
	return name; 
	} 

else if(size>=temp->seat&&temp->status=='A')
{
node* curr=*line;

char* name;
name =temp->naam;

free(t->next);
t->next=temp->next;
return name;
}
else
{

return 0;
}
}

}




int CountGroupsAhead(node *line,char* name)
{
node* temp=line;
node* t=line;
int count=0;
while(temp->next!=NULL&&strcmp(temp->naam,name)!=0)
{

temp=temp->next;
}

while(strcmp(temp->naam,t->naam)!=0)
{

count++;
//printf("%d:- %s of group size %d\n",count,t->naam,t->seat);
t=t->next;

}
return count;
}



int DisplayGroupSizeAhead(node* temp,node* t,char* name)
{
//node* temp=line;
//node* t=line;

//while(temp->next!=NULL&&strcmp(temp->naam,name)!=0)
//{
//temp=temp->next;
//}
if(strcmp(temp->naam,t->naam)!=0)
{
return t->seat;
}
}





void DisplayListInfo(node* temp)
{
int x=0;
while(temp!=NULL)
{
x++;
printf("%d:- name=%s size=%d ",x,temp->naam,temp->seat);
if(temp->status=='A')
printf("status= Arrived in restaurnt\n");
if(temp->status=='U')
printf("status= Has not arrived in the restaurant\n");
temp=temp->next;
}
}







