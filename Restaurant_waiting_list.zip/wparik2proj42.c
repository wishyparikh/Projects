#include "wparik2proj4.h"

void doAdd (node** line,char ch,int debugMode)
{
node* curr=*line;

node* temp=*line;
 /* get group size from input */
 int size = getPosInt();
 if (size < 1)
   {
    printf ("Error: Add command requires an integer value of at least 1\n");
    printf ("Add command is of form: a <size> <name>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    printf ("         <name> is the name of the group making the reservation\n");
    return;
   }

 /* get group name from input */
 char *name = getName();
 if (NULL == name)
   {
    printf ("Error: Add command requires a name to be given\n");
    printf ("Add command is of form: a <size> <name>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    printf ("         <name> is the name of the group making the reservation\n");
    return;
   }
int x;
x=DoesNameExist(*line,name,ch);
if(x==1)
{
return;
}
printf ("Adding group \"%s\" of size %d\n", name, size);

if(debugMode==1)
{
printf("In debug mode\n");
printf("%s was pushed  into the queue and was added in the end\n",name);
}

*line=addToList(*line,name,size,ch);


 // add code to perform this operation here
}


void doCallAhead (node** line,char ch)
{
node* temp=*line;
node* curr=*line;
 /* get group size from input */
 int size = getPosInt();
 if (size < 1)
   {
    printf ("Error: Call-ahead command requires an integer value of at least 1\n");
    printf ("Call-ahead command is of form: c <size> <name>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    printf ("         <name> is the name of the group making the reservation\n");
    return;
   }

 /* get group name from input */
 char *name = getName();
 if (NULL == name)
   {
    printf ("Error: Call-ahead command requires a name to be given\n");
    printf ("Call-ahead command is of form: c <size> <name>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    printf ("         <name> is the name of the group making the reservation\n");
    return;
   }


int x;
x=DoesNameExist(*line,name,ch);
if(x==1)
{
return;
}

 printf ("Call-ahead group \"%s\" of size %d\n", name, size);

*line=addToList(*line,name,size,ch);


 // add code to perform this operation here
}




void doWaiting (node** line,char ch)
{
node* temp=*line;
 /* get group name from input */
 char *name = getName();
 if (NULL == name)
   {
    printf ("Error: Waiting command requires a name to be given\n");
    printf ("Waiting command is of form: w <name>\n");
    printf ("  where: <name> is the name of the group that is now waiting\n");
    return;
   }

while(temp!=NULL)
{

if((temp->status=='U')&&(strcmp(temp->naam,name)==0))
{
int x;
x=UpdateStatus(temp,name);
if(x==1)
printf ("Waiting group \"%s\" is now in the restaurant\n", name);
break;
}
else if((temp->status=='A')&&(strcmp(temp->naam,name)==0)&&(DoesNameExist(*line,name,ch)==1))
{
printf("%s is already in the restaurant\n",temp->naam);
return;
}
else if(temp->next==NULL&&DoesNameExist(*line,name,ch)==0)
{
printf("name not foud in the list\n");
return;
}
temp=temp->next;
}



// add code to perform this operation here
}


void doRetrieve (node** line,int debugMode)
{
node* curr=*line;

 /* get table size from input */
 int size = getPosInt();
 if (size < 1)
   {
    printf ("Error: Retrieve command requires an integer value of at least 1\n");
    printf ("Retrieve command is of form: r <size>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    return;
   }
 clearToEoln();


char* name=retriveandRemove(&curr,size);
if(name!=0)
{
if(debugMode==1)
{
printf("In debug mode\n");
printf("the whole list is called and the matched 1st group was removed from the front\n");
}
printf("%s was alloted a table\n",name);
}
else
{
if(debugMode==1)
{
printf("In debug mode\n");
printf("the whole list is called and no groups were alloted as the size or status didnt match\n");
}
printf("no group in the list can be alloted a table\n");
}
*line=curr;
// add code to perform this operation here
}




void doList (node** line,char ch)
{
node* temp=*line;

node* t= *line;
int count=0;
 /* get group name from input */
 char *name = getName();
 if (NULL == name)
   {
    printf ("Error: List command requires a name to be given\n");
    printf ("List command is of form: l <name>\n");
    printf ("  where: <name> is the name of the group to inquire about\n");
    return;
   }

 

while(temp->next!=NULL&&strcmp(temp->naam,name)!=0)
{

temp=temp->next;
}
if(temp->next==NULL&&strcmp(temp->naam,name)!=0&&DoesNameExist(*line,name,ch)==0)
{
printf("The name not found in the list\n");
return;
}

if(strcmp(temp->naam,name)==0)
{
while(strcmp(temp->naam,t->naam)!=0)
{
int y;
y=DisplayGroupSizeAhead(temp,t,name);

count++;
printf("%d:- %s of group size %d\n",count,t->naam,y);
t=t->next;

}
int x=0;
x=CountGroupsAhead(*line,name);

printf ("\tGroup \"%s\" is behind the above %d groups\n", name,x);


}


 // add code to perform this operation here
}




void doDisplay (node** line)
{
node* temp= *line;
 clearToEoln();
 
 printf ("Display information about all groups\n");

DisplayListInfo(temp);



 // add code to perform this operation here
}