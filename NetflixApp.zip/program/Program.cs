/*Program.cs*/

//
// Wishy Parikh
// U. of Illinois, Chicago
// CS 341, Fall 2018
// Project #06: Netflix database application
//

using System;
using System.Data;
using System.Data.SqlClient;

namespace program
{

  class Program
  {
    //
    // Connection info for ChicagoCrimes database in Azure SQL:
    //
    static string connectionInfo = String.Format(@"
Server=tcp:jhummel2.database.windows.net,1433;Initial Catalog=Netflix;
Persist Security Info=False;User ID=student;Password=cs341!uic;
MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;
Connection Timeout=30;
");
// SELECT Count(*) As NumMovies FROM Movies


    static void OutputNumMovies()                                //this will output number of Movies if you press m and search by a substring and movie ID
    {
      SqlConnection db = null;
        
   try
      {
        db = new SqlConnection(connectionInfo);
        db.Open();
        
          System.Console.WriteLine("Enter Movie ID or part of the movie name");
        
        string input  =  System.Console.ReadLine();
        
        int id;
          string sql = null;
         string  code    =  System.Convert.ToString(input);
          input = input.Replace("'","''");
       int breakpoint = 0;
        
        if(System.Int32.TryParse(input,  out id))   // here it will check if the user entered id or string. below is the sql query to search and create table
        {
            sql = string.Format(@"SELECT Movies.MovieID, MovieName, MovieYear, Count(*) AS Numrev, AVG(CONVERT(float,Rating))  AS  AvgRating
                                    FROM Movies
                                    INNER JOIN Reviews ON Movies.MovieID = Reviews.MovieID
                                    GROUP BY Movies.MovieID, MovieName, MovieYear
                                    Having Movies.MovieID = {0}", id);
            breakpoint = 1;
        }
        else
        {
           sql = string.Format(@"SELECT Movies.MovieID, MovieName, MovieYear, Count(*) AS Numrev, AVG(CONVERT(float,Rating))  AS  AvgRating
                                    FROM Movies
                                    INNER JOIN Reviews ON Movies.MovieID = Reviews.MovieID
                                    GROUP BY Movies.MovieID, MovieName, MovieYear
                                    Having MovieName LIKE '%{0}%' 
                                    ORDER BY MovieName", input);
            breakpoint = 2;
        } 
        

       // System.Console.WriteLine(sql);  // debugging:
          
         SqlCommand  cmd                  =  new  SqlCommand();
          cmd.Connection                  =  db;  
          SqlDataAdapter  adapter  =  new  SqlDataAdapter(cmd);
          DataSet  ds                          =  new  DataSet();
          cmd.CommandText  =  sql;  
          adapter.Fill(ds);  
          var  rows  =  ds.Tables["TABLE"].Rows;  
           // System.Console.WriteLine(rows.Count);
          
          
          if(rows.Count != 0)                            //as the table is created it will print the data as per the table.
          {
          foreach  (DataRow  row  in  rows)  
          {  
              
                  System.Console.WriteLine("ID: {0}\nName: '{1}'\nYear: {2}\nNum reviews: {3}\nAvg rating: {4:0.00000}",  row["MovieID"],  row["MovieName"], 
                                           row["MovieYear"], row["Numrev"], row["AvgRating"]);
                  System.Console.WriteLine("\n");
          }       
          }
          if(rows.Count == 0)   // this section is for the part where there is no info after joining the tables.. so it will only print the data of the movies
                                  //even if there are no reviews.
          {
              db.Close();
              cmd                  =  new  SqlCommand();
          cmd.Connection                  =  db;  
         adapter  =  new  SqlDataAdapter(cmd);
           ds                          =  new  DataSet();       //the sql query will search only in Movies as there is no data in the reviews for that specific movie.
              if(breakpoint == 1)
              sql = string.Format(@"SELECT MovieID, MovieName, MovieYear FROM Movies WHERE MovieID = {0}", id);
              
              if(breakpoint == 2)
                  sql = string.Format(@"SELECT MovieID, MovieName, MovieYear FROM Movies WHERE MovieName LIKE '%{0}%' ORDER BY MovieName", input);
                  
              String avgrate = "N/A";
              int rate = 0;
          cmd.CommandText  =  sql;  
          adapter.Fill(ds);  
          var  rows2  =  ds.Tables["TABLE"].Rows;            //now store in table and print the values of table.
                  
              if(rows2.Count != 0)
                {
                      foreach  (DataRow  row  in  rows2)  
                      {  
              
                          System.Console.WriteLine("ID: {0}\nName: '{1}'\nYear: {2}\nNum reviews: {3}\nAvg rating: {4}",  row["MovieID"],  row["MovieName"], 
                                                   row["MovieYear"], rate, avgrate);
                          System.Console.WriteLine("\n");
                      }       
                  } 
              
                 else
                 {
                     System.Console.WriteLine("** Movie not found...");
                 }
              
      }
               
        db.Close();
        
       
      }
      catch (Exception ex)
      {
        System.Console.WriteLine();
        System.Console.WriteLine("**Error: {0}", ex.Message);
        System.Console.WriteLine();
      }
      finally
      {
				// make sure we close connection no matter what happens:
        if (db != null && db.State != ConnectionState.Closed)
          db.Close();
      }
    }
      
      
      
       
      
      static void OutputNumReviews()                  // this is for the reviews part if the user will press u.
    {
      SqlConnection db = null;
      
      try
      {
        db = new SqlConnection(connectionInfo);
        db.Open();
        
      System.Console.WriteLine("Enter User ID or name");
        
        string input  =  System.Console.ReadLine();
          input = input.Replace("'","''");
        
        int id;
          int breakpoint = 0;
          string sql = null;
         string  code    =  System.Convert.ToString(input);     // below is the sql query for joining the user and reviews table and then selecting the data as per the user name and user id.
                                                                //i used UNION ALL to make 2 queries and overlap 2 tables one will get the total reviews ad other will get stars.
        if(System.Int32.TryParse(input,  out id))  //this will see if the input is user id or username
        {
            sql = string.Format(@"SELECT UserName, Users.UserID, Occupation, AVG(CONVERT(float,Rating))  AS  AvgRating, Count(*) AS Numrev
                                FROM Users
                                INNER JOIN Reviews ON Users.UserID = Reviews.UserID
                                WHERE Users.UserID = {0}
                                GROUP BY Users.UserID, UserName, Occupation

                                UNION ALL

                                SELECT UserName, Users.UserID, Occupation, AVG(CONVERT(float,Rating))  AS  AvgRating, Count(*) AS Numrev
                                FROM Users
                                INNER JOIN Reviews ON Users.UserID = Reviews.UserID
                                WHERE Users.UserID = {0}
                                GROUP BY Users.UserID, UserName, Occupation, Rating", id);
            breakpoint = 1;
        }
        else
        {
           sql = string.Format(@"SELECT UserName, Users.UserID, Occupation, AVG(CONVERT(float,Rating))  AS  AvgRating, Count(*) AS Numrev
                                FROM Users
                                INNER JOIN Reviews ON Users.UserID = Reviews.UserID
                                WHERE UserName LIKE '%{0}%'
                                GROUP BY Users.UserID, UserName, Occupation

                                UNION ALL

                                SELECT UserName, Users.UserID, Occupation, AVG(CONVERT(float,Rating))  AS  AvgRating, Count(*) AS Numrev
                                FROM Users
                                INNER JOIN Reviews ON Users.UserID = Reviews.UserID
                                WHERE UserName LIKE '%{0}%' 
                                GROUP BY Users.UserID, UserName, Occupation, Rating", input);
            breakpoint = 2;
        } 
        

      //  System.Console.WriteLine(sql);  // debugging:
          
          
          
//      SqlCommand cmd = new SqlCommand();
//         cmd.Connection = db;
//         cmd.CommandText = sql;
    SqlCommand  cmd                  =  new  SqlCommand();
          cmd.Connection                  =  db;  
          SqlDataAdapter  adapter  =  new  SqlDataAdapter(cmd);
          DataSet  ds                          =  new  DataSet();
          cmd.CommandText  =  sql;  
          adapter.Fill(ds);  
          var  rows  =  ds.Tables["TABLE"].Rows;      // now after running the sql query the table s created and data is stored in it.
           // System.Console.WriteLine(rows.Count);
          
          int i = 0;
          int rate = 0;
          int four = 0;
          int five = 0;
          if(rows.Count != 0)             //for each row in the table output the data. in a loop accordig to the rows.
          {
              foreach  (DataRow  row  in  rows)  
          {
                   if(i == 0) //for 1st row before union
                  {
                      System.Console.WriteLine("Name: {0}\nUser id: {1}\nOccupation: {2}\nAvg rating: {3:0.00000}\nNum reviews: {4}",  row["UserName"],  row["UserID"], 
                                           row["Occupation"], row["AvgRating"], row["Numrev"]);
                  }
                  
                    if(i == 1)    //for row 1
                  {
                      int temp = Int32.Parse(row["AvgRating"].ToString());
                      if(temp == 1)
                      {
                      System.Console.WriteLine("1 Star: {0}\n",  row["Numrev"]);
                      }
                      else
                      {
                          System.Console.WriteLine("1 Star: {0}\n",  rate);
                          i++;
                      }
                          
                  } 
                  if(i == 2)  //for row 2 
                  {
                      int temp = Int32.Parse(row["AvgRating"].ToString());
                      if(temp == 2)
                      {
                      System.Console.WriteLine("2 Star: {0}\n",  row["Numrev"]);
                      }
                      else
                      {
                          System.Console.WriteLine("2 Star: {0}\n",  rate);
                          i++;
                      }
                  } 
                  if(i == 3)
                  {
                      int temp = Int32.Parse(row["AvgRating"].ToString());
                      if(temp == 3)
                      {
                      System.Console.WriteLine("3 Star: {0}\n",  row["Numrev"]);
                      }
                      else
                      {
                          System.Console.WriteLine("3 Star: {0}\n",  rate);
                          i++;
                      }
                  } 
                  if(i == 4)
                  {
                      int temp = Int32.Parse(row["AvgRating"].ToString());
                      if(temp == 4)
                      {
                      System.Console.WriteLine("4 Star: {0}\n",  row["Numrev"]);
                          four = 1;
                      }
                      else
                      {
                          System.Console.WriteLine("4 Star: {0}\n",  rate);
                          four = 1;
                          i++;
                      }
                      
                      
                  } 
                  if(i == 5)
                  {
                      int temp = Int32.Parse(row["AvgRating"].ToString());
                      if(temp == 5)
                      {
                      System.Console.WriteLine("5 Star: {0}\n",  row["Numrev"]);
                          five = 1;
                      }
                      else
                      {
                          System.Console.WriteLine("5 Star: {0}\n",  rate);
                          five = 1;
                          
                      }
                  } 
                 
                                
                  
                  i++;
                  
                  
              }
              
              
              if(four == 1 && five ==0)
              {
                  System.Console.WriteLine("5 Star: {0}\n",  rate);
              }
              
              
              
          } 
          
          
          if(rows.Count == 0)                    // now if there is no data after using join. search in the Users table only. If the data is in users table 
                                                  // then print if not in the users table then it will be user not found.
          {
              db.Close();
              cmd                  =  new  SqlCommand();
          cmd.Connection                  =  db;  
         adapter  =  new  SqlDataAdapter(cmd);
           ds                          =  new  DataSet();     //below is the query to search only in the users table.
              if(breakpoint == 1)
              sql = string.Format(@"SELECT UserName, UserID, Occupation FROM Users WHERE UserID = {0}", id);
              
              if(breakpoint == 2)
                  sql = string.Format(@"SELECT UserName, UserID, Occupation FROM Users WHERE UserName LIKE '%{0}%'", input);
                  
              String avgrate = "N/A";
              int rate1 = 0;
          cmd.CommandText  =  sql;  
          adapter.Fill(ds);  
          var  rows2  =  ds.Tables["TABLE"].Rows;
                  
              if(rows2.Count != 0)
                {
                      foreach  (DataRow  row  in  rows2)  
                      {  
              
                          System.Console.WriteLine("Name: {0}\nID: {1}\nOccupation: {2}\nAvg rating: {4}\nNum reviews: {3}",  row["UserName"],  row["UserID"], 
                                                   row["Occupation"], avgrate, rate1);
                          System.Console.WriteLine("\n");
                      }       
                  } 
              else
          {
                  System.Console.WriteLine("** User not found...");
          }
          
          }
          
          
         db.Close();
        
        //int numMovies = System.Convert.ToInt32(result);
				//System.Console.WriteLine(result);
				//System.Console.WriteLine("Number of movies: {0}", numMovies);
      }
      catch (Exception ex)
      {
        System.Console.WriteLine();
        System.Console.WriteLine("**Error: {0}", ex.Message);
        System.Console.WriteLine();
      }
      finally
      {
				// make sure we close connection no matter what happens:
        if (db != null && db.State != ConnectionState.Closed)
          db.Close();
      }
    }
      
      
      
      
      static void OutputTopten()     // this is for outputing the top10 movies..
      {
           SqlConnection db = null;
        
       try
      {
        db = new SqlConnection(connectionInfo);     // below is the query for selectiong top 10 movies in decending order of the avgrating.
        db.Open();
        
         
        
       
          String  sql = string.Format(@"SELECT TOP 10 Movies.MovieID, Count(*) AS Numrev, AVG(CONVERT(float,Rating))  AS  AvgRating, MovieName
                                  FROM Movies
                                INNER JOIN Reviews ON Movies.MovieID = Reviews.MovieID
                                GROUP BY Movies.MovieID, MovieName, MovieYear  
                                ORDER BY AvgRating DESC");
         
       // System.Console.WriteLine(sql);  // debugging:
          
         SqlCommand  cmd                  =  new  SqlCommand();
          cmd.Connection                  =  db;  
          SqlDataAdapter  adapter  =  new  SqlDataAdapter(cmd);
          DataSet  ds                          =  new  DataSet();
          cmd.CommandText  =  sql; 
           int i = 0;
          adapter.Fill(ds);  
          var  rows  =  ds.Tables["TABLE"].Rows;  
           // System.Console.WriteLine(rows.Count);
          
          
          if(rows.Count != 0)          //if the table is created then output the data of top 10 movies.
          {
               System.Console.WriteLine("Rank\t MovieID\t NumReviews\t AvgRating\t MovieName\n");
              
          foreach  (DataRow  row  in  rows)  
          {  
              i++;
              
                  System.Console.WriteLine("{0}\t {1}\t\t {2}\t\t {3:0.00000}\t '{4}'",i, row["MovieID"], row["Numrev"], row["AvgRating"], row["MovieName"]);
          }       
          }
         
               
        db.Close();
        
       
      }
      catch (Exception ex)
      {
        System.Console.WriteLine();
        System.Console.WriteLine("**Error: {0}", ex.Message);
        System.Console.WriteLine();
      }
      finally
      {
				// make sure we close connection no matter what happens:
        if (db != null && db.State != ConnectionState.Closed)
          db.Close();
      }
          
          
          
      }
      

    static string GetUserCommand()
    {
      System.Console.WriteLine();
      System.Console.WriteLine("What would you like?");
      System.Console.WriteLine("m. movie info");
      System.Console.WriteLine("t. top-10 info");
      System.Console.WriteLine("u. user info");
      System.Console.WriteLine("x. exit");
      System.Console.Write(">> ");

      string cmd = System.Console.ReadLine();

      return cmd.ToLower();
    }


    //
    // Main:
    //
    static void Main(string[] args)
    {
      System.Console.WriteLine("** Netflix Database App **");

      string cmd = GetUserCommand();

      while (cmd != "x")    // loop for calling the functions for user input. x for close..
      {
				if(cmd == "m")
                {
                System.Console.WriteLine();
				OutputNumMovies();
                }
                  
          if(cmd == "u")
                {
                System.Console.WriteLine();
				OutputNumReviews();
                }
          if(cmd == "t")
                {
                System.Console.WriteLine();
				OutputTopten();
                }
          
        cmd = GetUserCommand();
      }

      System.Console.WriteLine();
      System.Console.WriteLine("** Done **");
      System.Console.WriteLine();
    }

  }//class
}//namespace

