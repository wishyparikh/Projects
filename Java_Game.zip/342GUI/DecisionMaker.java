
public interface DecisionMaker 
{
	
	Move getMove ( Character c, Place p );

}
