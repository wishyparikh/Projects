
public interface  UserInterface 
{
	
	public void display( String output);  
	public String getLine();
	public void playerName(Character me);
	public void cleartext();
}
