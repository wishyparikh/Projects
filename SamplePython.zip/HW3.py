import Person
import Group

#this is the driver code to test the functions of the person and group class


class HW3:

    numpeople = []   #keeping track of total person
    numgroups = []     #keeping track of total groups
    identity = 0        #creating unique ID everytime a person is created
    grpid = 0           #creating unique ID everytime a group is created
    while True:         #loop till -1
        userInput = eval(input("Choose an option: "))
        if userInput == -1:
            print("Goodbye!")
            break
        if userInput == 0:
            print("On -1, end the loop.")
            print("On 0, output what each number does")
            print("On 1, create a new Person. Ask for the first and last name.")
            print("On 2, create a new group, populated by existing Person objects. Loop while outputting the names of "
                  "people who have not been assigned to a group and ask for the ids of the people to add.")
            print("On 3, allow the user to modify an existing group. Ask the user which group they wish to modify. "
                  "Then ask whether they are trying to add or remove members to/from the group. Then, interactively "
                  "allow "
                  "the user to add or remove as many users as they want by offering a list of available choices and "
                  "having "
                  "the user select which member to interact with.")
            print("On 4, validate all existing groups, as well as all people to check that they have a group.")
            print("On 5, output each group’s number and members.")
        if userInput == 1:    #calling create person constructor.
            identity = identity + 1
            firstname = input("What is the person's first name? ")
            lastname = input("What is the person's last name? ")
            p1 = Person.Person({"ID": identity, "First Name": firstname, "Last Name": lastname})
            numpeople.append(p1)

        if userInput == 2:    #calling create group
            grpid = grpid + 1
            g1 = Group.Group(grpid)
            while True:
                for x in numpeople:
                    if "GroupNum" not in x.attributes:
                        print(x.attributes["ID"], " ", x.attributes["First Name"] + " " + x.attributes["Last Name"])
                txt = eval(input("Which person would you like to add to the new group? (-1 to finish adding people): "))
                if txt == -1:
                    break
                else:
                    for y in numpeople:
                        if txt == y.attributes["ID"]:
                            g1.addperson(y, grpid)
            numgroups.append(g1)
        if userInput == 3:
            print()
            txt = eval(input("Which group would you like to modify? "))
            print()
            txt1 = input("Would you like to ADD or REMOVE members? ")
            if txt1 == "REMOVE":
                for group in numgroups:
                    if txt == group.ID:
                        i = 0
                        while True:
                            for y in group.ListofPeople:
                                i = i + 1
                                print(i, " ", y.attributes["First Name"] + " " + y.attributes["Last Name"])
                            print()
                            txt3 = eval(input("Which person would you like to remove from the group? (-1 to finish "
                                              "removing people): "))
                            if txt3 == -1:
                                break
                            else:
                               delid = group.removeperson(txt3)    #delete that person from track of person too.
                               i = 0
                               for p in numpeople:
                                   if delid == p.attributes["ID"]:
                                       del p.attributes["GroupNum"]
            if txt1 == "ADD":       #calling add function to add people.
                for group in numgroups:
                    if txt == group.ID:
                        while True:
                            for x in numpeople:
                                if "GroupNum" not in x.attributes:
                                    print(x.attributes["ID"], " ", x.attributes["First Name"] + " " + x.attributes["Last Name"])
                            print()
                            txt3 = eval(input("Which person would you like to add to the group? (-1 to finish "
                                              "adding people): "))
                            if txt3 == -1:
                                break
                            else:
                                for x in numpeople:
                                    if x.attributes["ID"] == txt3:
                                        group.addperson(x, txt3)
        if userInput == 4:
            for person in numpeople:
                person.validate()
            for group in numgroups:
                group.validate()
        if userInput == 5:
            for group in numgroups:
                print("Group", group.ID)
                for person in group.ListofPeople:
                    print(person.attributes["First Name"] + " " + person.attributes["Last Name"])
