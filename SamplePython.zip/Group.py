import Person
#This is the Group class for creating a group and adding or removing people from the group.


class Group(object):

    totalgroups = 0         #Keeping count of total number of groups created
    ID = 0                   #Id of perticular Group
    ListofPeople = []            #List of people in group

    def __init__(self, id):
        self.ID = id
        self.ListofPeople = []
        self.totalgroups = self.totalgroups + 1

    def addperson(self, person, grpid):    #function to add person in group
        if "GroupNum" not in person.attributes:
            self.ListofPeople.append(Person.Person({"ID": person.attributes["ID"], "First Name": person.attributes["First Name"], "Last Name": person.attributes["Last Name"], "GroupNum": grpid}))
            person.attributes["GroupNum"] = grpid

    def removeperson(self, index):     #function to remove a person from group
        del self.ListofPeople[index-1].attributes["GroupNum"]
        delid = self.ListofPeople[index-1].attributes["ID"]
        del self.ListofPeople[index-1]
        return delid

    def validate(self):      #validate funtion that checks if person is assigned toa  group
        for x in self.ListofPeople:
            x.validate(["ID", "First Name", "Last Name", "GroupNum"])
        if len(self.ListofPeople) > 5:
            print("Group ", self.ID, " has ", len(self.ListofPeople), " people, more than five")
        if len(self.ListofPeople) < 3:
            print("Group ", self.ID, " has ", len(self.ListofPeople), " people, less than three")
