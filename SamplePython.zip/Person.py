#this is a person class that has a dictionary which stores name id and group number of the person


class Person(object):

  totalpersons = 0         #total people
  attributes = dict()      #dict for storing name id and groupnumber

  def __init__(self, values=None):    #constructor for person
      if values is None:
          values = []
      else:
        self.totalpersons = self.totalpersons + 1
        self.attributes = values.copy()

  def validate(self, listofattributes=None):    #validate functin which checks all the attributes are present for a person or not.
     if listofattributes is None:
        if "GroupNum" not in self.attributes:
            print(self.attributes["First Name"] + " " + self.attributes["Last Name"] + " does not have an "
                                                                                       "assigned group.")
     else:
        if "ID" not in self.attributes:
            print("Person has no ID")

        if "First Name" not in self.attributes:
            print("Person", self.attributes["ID"], "has no first name")

        if "Last Name" not in self.attributes:
            print("Person", self.attributes["ID"], "has no last name")

        if "GroupNum" not in self.attributes:
            print("Person", self.attributes["ID"], "has no group number")
