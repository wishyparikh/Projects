using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Threading.Tasks;  
using Microsoft.AspNetCore.Mvc;  
using Microsoft.AspNetCore.Mvc.RazorPages;  
using System.Data;
  
namespace crimes.Pages  
{  
    public class ListOfAreaModel : PageModel  
    {  
				public List<Models.Crime> CrimeList { get; set; }
				public Exception EX { get; set; }
  
        public void OnGet(string input)  
        {  
				  List<Models.Crime> crimes = new List<Models.Crime>();
					
					// clear exception:
					EX = null;
             
					try
					{
							string sql = null;

							
								sql = string.Format(@"
	SELECT Areas.Area AS AreaNum ,  AreaName, Count(Crimes.Area) AS TotalCrimes, ROUND((CONVERT(float,COUNT(*)) * 100.0 / (Select count(*) from Crimes)),2) AS Percentage   
    FROM Areas
    INNER JOIN Crimes ON Crimes.Area = Areas.Area
    WHERE Areas.Area > 0
    GROUP BY Areas.Area, AreaName
    ORDER BY AreaName ASC;
	");

    
							
							DataSet ds = DataAccessTier.DB.ExecuteNonScalarQuery(sql);

							foreach (DataRow row in ds.Tables["TABLE"].Rows)
							{
								Models.Crime c = new Models.Crime();

                                c.AreaNum = Convert.ToInt32(row["AreaNum"]);
                                c.AreaName = Convert.ToString(row["AreaName"]);
                                c.TotalCrimes = Convert.ToInt32(row["TotalCrimes"]);
                                c.Percentage = Convert.ToDouble(row["Percentage"]);
                              
								crimes.Add(c);
							}
                         
					
					}
					catch(Exception ex)
					{
					  EX = ex;
					}
					finally
					{
					  CrimeList = crimes;
					 // NumMovies = movies.Count;
				  }
				}
			
    }//class  
}//namespace