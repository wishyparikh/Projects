using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Threading.Tasks;  
using Microsoft.AspNetCore.Mvc;  
using Microsoft.AspNetCore.Mvc.RazorPages;  
using System.Data;
  
namespace crimes.Pages  
{  
    public class CityInfoModel : PageModel  
    {  
				public List<Models.Crime> CrimeList { get; set; }
				public string Input { get; set; }
				public int CityNum { get; set; } //Number of the city
                public string CityName { get; set; } //Name of the city
				public Exception EX { get; set; }
  
        public void OnGet(string input)  
        {  
				  List<Models.Crime> crimes = new List<Models.Crime>();
					
					// make input available to web page:
					Input = input;
                    
					
					// clear exception:
					EX = null;
             
					try
					{
						//
						// Do we have an input argument?  If so, we do a lookup:
						//
						if (input == null)
						{
							//
							// there's no page argument, perhaps user surfed to the page directly?  
							// In this case, nothing to do.
							//
						}
						else  
						{
							// 
							// Lookup movie(s) based on input, which could be id or a partial name:
							// 
							int id;
							string sql = null;
                            string pql = null;

							if (System.Int32.TryParse(input, out id))
							{
								sql = string.Format(@"
	SELECT TOP 10 COUNT(*) AS NumCrimes, PrimaryDesc, SecondaryDesc, ROUND((CONVERT(float,COUNT(*)) * 100.0 / (Select count(*) from Crimes)),2) AS Percentage,
    ROUND(AVG(CONVERT(float,Arrested))*100.0,  2) AS ArestPer, Crimes.IUCR 
    FROM Crimes
    INNER JOIN Codes ON Crimes.IUCR = Codes.IUCR 
    INNER JOIN Areas ON Areas.Area = Crimes.Area
    WHERE Areas.Area = {0}
    GROUP BY Crimes.IUCR, PrimaryDesc, SecondaryDesc
    ORDER BY NumCrimes DESC
	", id);
    
                                pql = string.Format(@"
    SELECT Area, AreaName FROM Areas
    WHERE Area = {0}
                                ", id);
    
    
							}
							else
							{
								// lookup movie(s) by partial name match:
								input = input.Replace("'", "''");

								sql = string.Format(@"
	SELECT TOP 10 COUNT(*) AS NumCrimes, PrimaryDesc, SecondaryDesc, ROUND((CONVERT(float,COUNT(*)) * 100.0 / (Select count(*) from Crimes)),2) AS Percentage,
    ROUND(AVG(CONVERT(float,Arrested))*100.0,  2) AS ArestPer, Crimes.IUCR 
    FROM Crimes
    INNER JOIN Codes ON Crimes.IUCR = Codes.IUCR 
    INNER JOIN Areas ON Areas.Area = Crimes.Area
    WHERE Areas.AreaName LIKE '%{0}%'
    GROUP BY Crimes.IUCR, PrimaryDesc, SecondaryDesc
    ORDER BY NumCrimes DESC
	", input);
    
     pql = string.Format(@"
    SELECT Area, AreaName FROM Areas
    WHERE AreaName LIKE '%{0}%'
                                ", input);
							}

							DataSet ds = DataAccessTier.DB.ExecuteNonScalarQuery(sql);
                            DataSet es = DataAccessTier.DB.ExecuteNonScalarQuery(pql);

							foreach (DataRow row in ds.Tables["TABLE"].Rows)
							{
								Models.Crime c = new Models.Crime();

								c.IUCR = Convert.ToString(row["IUCR"]);
                                c.NumCrimes = Convert.ToInt32(row["NumCrimes"]);
                                c.PrimaryDesc = Convert.ToString(row["PrimaryDesc"]);
                                c.SecondaryDesc = Convert.ToString(row["SecondaryDesc"]);
                                c.Percentage = Convert.ToDouble(row["Percentage"]);                                
                                c.ArestPer = Convert.ToDouble(row["ArestPer"]);
                            

								// avg rating could be null if there are no reviews:
								/*if (row["AvgRating"] == System.DBNull.Value)
									m.AvgRating = 0.0;
								else
									m.AvgRating = Convert.ToDouble(row["AvgRating"]);*/

								crimes.Add(c);
							}
                            
                            foreach (DataRow row in es.Tables["TABLE"].Rows)
							{
								 CityNum = Convert.ToInt32(row["Area"]);
                                 CityName = Convert.ToString(row["AreaName"]);
							}
						}//else
					}
					catch(Exception ex)
					{
					  EX = ex;
					}
					finally
					{
					  CrimeList = crimes;
					 // NumMovies = movies.Count;
				  }
				}
			
    }//class  
}//namespace