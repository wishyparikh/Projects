using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Threading.Tasks;  
using Microsoft.AspNetCore.Mvc;  
using Microsoft.AspNetCore.Mvc.RazorPages;  
using System.Data;
  
namespace crimes.Pages  
{  
    public class CrimeInfoModel : PageModel  
    {  
				public List<Models.Crime> CrimeList { get; set; }
				public string Input { get; set; }
				public Exception EX { get; set; }
  
        public void OnGet(string input)  
        {  
				  List<Models.Crime> crimes = new List<Models.Crime>();
					
					// make input available to web page:
					Input = input;
                    
					
					// clear exception:
					EX = null;
             
					try
					{
						//
						// Do we have an input argument?  If so, we do a lookup:
						//
						if (input == null)
						{
							//
							// there's no page argument, perhaps user surfed to the page directly?  
							// In this case, nothing to do.
							//
						}
						else  
						{
							// 
							// Lookup movie(s) based on input, which could be id or a partial name:
							// 
							int id;
							string sql = null;
                            

							if (System.Int32.TryParse(input, out id))
							{
                               
                                 sql = null;
    
							}
							else
							{
								// lookup movie(s) by partial name match:
								input = input.Replace("'", "''");

								sql = string.Format(@"
        SELECT AreaName, Count(*) AS TotalCrimes FROM Areas
INNER JOIN Crimes ON Areas.Area = Crimes.Area
INNER JOIN Codes ON Crimes.IUCR = Codes.IUCR
WHERE PrimaryDesc LIKE '%{0}%'
GROUP BY AreaName
ORDER BY TotalCrimes DESC
        ", input);
							}

							DataSet ds = DataAccessTier.DB.ExecuteNonScalarQuery(sql);

							foreach (DataRow row in ds.Tables["TABLE"].Rows)
							{
								Models.Crime c = new Models.Crime();
                                
                                c.AreaName = Convert.ToString(row["AreaName"]);
                                c.TotalCrimes = Convert.ToInt32(row["TotalCrimes"]);
                                
								crimes.Add(c);
							}
                         
						}//else
					}
					catch(Exception ex)
					{
					  EX = ex;
					}
					finally
					{
					  CrimeList = crimes;
					 // NumMovies = movies.Count;
				  }
				}
			
    }//class  
}//namespace