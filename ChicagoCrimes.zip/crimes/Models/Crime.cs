//
// One crime
//

namespace crimes.Models
{

  public class Crime
	{
	
		// data members with auto-generated getters and setters:
	    
      
        public string IUCR { get; set; }
        public double ArestPer { get; set; }
        public int NumCrimes { get; set; }
        public string PrimaryDesc { get; set; }
        public string SecondaryDesc { get; set; }
        public double Percentage { get; set; }
        public int TotalCrimes { get; set; }
        public string CrimeDate { get; set; }
        public int AreaNum { get; set; }
        public string AreaName { get; set; }
      
 

		// default constructor:
		public Crime()
		{ }
      
		// constructor:
        public Crime(string ArName, int tc)
        {
            AreaName = ArName;
            TotalCrimes = tc;
        }
        public Crime(int An, string ArName, int tc, double per)
        {
            AreaNum = An;
            AreaName = ArName;
            TotalCrimes = tc;
            Percentage = per;
        }
		
		public Crime(string iucr, double ap, int numcrimes, string pD, string sD, double per, int tc)
		{
			IUCR = iucr; 
			ArestPer = ap;
			NumCrimes = numcrimes;
			PrimaryDesc = pD;
            SecondaryDesc = sD;
            Percentage = per;
            TotalCrimes = tc;
		}
		
	}//class

}//namespace