using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Threading.Tasks;  
using Microsoft.AspNetCore.Mvc;  
using Microsoft.AspNetCore.Mvc.RazorPages;  
using System.Data;
  
namespace crimes.Pages
{  
    public class CrimesTop10Model : PageModel  
    {  
        public List<Models.Crime> CrimeList { get; set; }
				public Exception EX { get; set; }
  
        public void OnGet()  
        {  
				  List<Models.Crime> crimes = new List<Models.Crime>();
					
					// clear exception:
					EX = null;
					
					try
					{
						string sql = string.Format(@"
	SELECT TOP 10 Crimes.IUCR, COUNT(*) AS NumCrimes, PrimaryDesc, SecondaryDesc, ROUND((CONVERT(float,COUNT(*)) * 100.0 / (Select count(*) from Crimes)),2) AS Percentage,
    ROUND(AVG(CONVERT(float,Arrested))*100.0,  2) AS ArestPer FROM Crimes
    INNER JOIN Codes ON Crimes.IUCR = Codes.IUCR 
    GROUP BY Crimes.IUCR, PrimaryDesc, SecondaryDesc  
    ORDER BY NumCrimes DESC
	");

						DataSet ds = DataAccessTier.DB.ExecuteNonScalarQuery(sql);

						foreach (DataRow row in ds.Tables["TABLE"].Rows)
						{
							Models.Crime c = new Models.Crime();

							c.IUCR = Convert.ToString(row["IUCR"]);
							c.NumCrimes = Convert.ToInt32(row["NumCrimes"]);
							c.PrimaryDesc = Convert.ToString(row["PrimaryDesc"]);
                            c.SecondaryDesc = Convert.ToString(row["SecondaryDesc"]);
                            c.Percentage = Convert.ToDouble(row["Percentage"]);
                            c.ArestPer = Convert.ToDouble(row["ArestPer"]);
                            
							crimes.Add(c);
						}
					}
					catch(Exception ex)
					{
					  EX = ex;
					}
					finally
					{
            CrimeList = crimes;  
				  }
        }  
				
    }//class
}//namespace